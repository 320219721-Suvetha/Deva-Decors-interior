var fs = require('fs');
const path = require('path')
var express = require('express')
var app = express()
const port = 8080
const router = {
    '/':'index.html',
    '/index':'index.html',
    '/contact':'contact.html',
    '/luxury':'luxury.html',
    '/about':'about.html',
    '/resident':'resident.html',
    '/officefurniture':'officefurniture.html',
    '/servicesingle':'servicesingle.html',
}
const header = fs.readFileSync('./header.html',{encoding:'utf8', flag:'r'});
const footer = fs.readFileSync('./footer.html',{encoding:'utf8', flag:'r'});



for (let route in router) {
    app.get(route, function(req, res) {
        fs.readFile(router[route], function(err, data) {
            if (err) {
              res.writeHead(404, {'Content-Type': 'text/html'});
              console.log()
              return res.end("404 Not Found");
            } 
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.write(header)
            res.write(data);
            return res.end(footer)
          });
          
      });
  }
  
app.use('/', express.static('assets'))
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})

